#include <iostream>
#include <math.h>
#include <stdio.h>
using namespace std;
template<typename T> class interval_components
{
    private:            //[x,y]
            T x;
            T y;
    public:
    interval_components(T _x=0, T _y=0):x(_x),y(_y){} //constructor
    ~interval_components(){}                          //destructor
    interval_components(const interval_components& p)  // copy constructor
    {
        *this=p;
    }
        interval_components& operator=(const interval_components& p)    //operator =
    {
        if(this==&p) return(*this);
        x=p.x;
        y=p.y;
        return (*this);
    }
    interval_components operator+(interval_components& p)  //operator + enable [x1,y1]+[x2,y2]
    {
        return(interval_components(T(x+p.x),(y+p.y)));
    }

   interval_components operator+(const T& p)             //operator + enable [x,y]+a  a is a constant
    {
        return(interval_components(T(x+p),T(y+p)));
    }
        interval_components operator-(const interval_components& p) //operator - enable[x,y]-[a,b]
    {
        return(interval_components(x-p.y,y-p.x));
    }
 interval_components operator-(const T& p)                          //operator - enable [x,y]-a
    {
        return(interval_components(T(x-p),T(y-p)));
    }
 interval_components operator*(const interval_components& p) //operator *   enable[x,y]*[a,b]
    {
        return(interval_components(min(min(x*p.x,x*p.y),min(y*p.x,y*p.y)),max(max(x*p.x,x*p.y),max(y*p.x,y*p.y))));//inline for optimization
    }
  interval_components operator*(const T& p) //operator * enable[x,y]*a
    {
        return(interval_components(T (min(x*p,y*p)),T (max(x*p,y*p))));//inline
    }
        interval_components operator / (const interval_components& p)// operator / enable [x,y]/[a,b]
    {
        return(interval_components(min(min(x/p.x,x/p.y),min(y/p.x,y/p.y)),max(max(x/p.x,x/p.y),max(y/p.x,y/p.y))));//inline
    }
  interval_components operator /(const T& p)    //operator / enable[x,y]/a;
    {
        return(interval_components(T (min(x/p,y/p)),T (max(x/p,y/p))));//inline
    }

    interval_components  square()         //calculate square
    {
        return(interval_components(T (min(x*x,y*y)),T (max(x*x,y*y))));
    }
    interval_components  squrt() //obtain square root
    {
         return(interval_components(T (sqrt(x)),T (sqrt(y))));
    }

     friend ostream& operator<<(ostream& out,interval_components &p)//output  operator
    {
         out<<"["<<p.x<<","<<p.y<<"]";
          return (out);
    }
};
