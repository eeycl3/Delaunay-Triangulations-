#include <iostream>
#include <math.h>
#include <stdio.h>
#include "Task3.h"
using namespace std;
int main()
{   int  n(2),m(-2);
    double e(-0.5),f(3.0);
    interval_components<double> a(3.5,5.5);
    interval_components<double> b(-1.5,-2.5);
    interval_components<double> aa(-4,5);
    interval_components<double> bb(-5,4);
    interval_components<double> aaa(0,5);
    interval_components<int> c(0,2);
    interval_components<int> d(-4,5);
    interval_components<double> result1;
    interval_components<int> result2;
    //addition
    cout<<"addition"<<endl;
    result1=a+n;
    cout<<a<<"+"<<n<<"="<<result1<<endl;
    result1=a+b;
    cout<<a<<"+"<<b<<"="<<result1<<endl;
    cout<<endl;
    //difference
    cout<<"difference"<<endl;
    result2=c-n;
    cout<<c<<"-"<<n<<"="<<result2<<endl;
    result2=d-c;
    cout<<d<<"-"<<c<<"="<<result2<<endl;
    cout<<endl;
    //multiplication
    cout<<"multipication"<<endl;
    result1=a*e;
    cout<<a<<"*"<<e<<"="<<result1<<endl;
    result1=a*f;
    cout<<a<<"*"<<f<<"="<<result1<<endl;
    result1=a*b;
    cout<<a<<"*"<<b<<"="<<result1<<endl;
    result1=b*aa;
    cout<<b<<"*"<<aa<<"="<<result1<<endl;
    result1=aa*bb;
    cout<<aa<<"*"<<bb<<"="<<result1<<endl;
    cout<<endl;
    //
    cout<<"division"<<endl;
    result1=a/0;
    cout<<a<<"/"<<0<<"="<<result1<<endl;
    result1=a/aaa;
    cout<<a<<"/"<<aaa<<"="<<result1<<endl;
    result1=a/e;
    cout<<a<<"/"<<e<<"="<<result1<<endl;
    result1=a/f;
    cout<<a<<"/"<<f<<"="<<result1<<endl;
    result1=a/b;
    cout<<a<<"/"<<b<<"="<<result1<<endl;
    result1=b/aa;
    cout<<b<<"/"<<aa<<"="<<result1<<endl;
    result1=aa/bb;
    cout<<aa<<"/"<<bb<<"="<<result1<<endl;
    cout<<endl;

    //square
    cout<<"square"<<endl;
    result1=a.square();
    cout<<a<<"square"<<"="<<result1<<endl;
    result1=b.square();
    cout<<b<<"square"<<"="<<result1<<endl;
    result1=bb.square();
    cout<<bb<<"square"<<"="<<result1<<endl;
    cout<<endl;

    //sqrt
    cout<<"sqrt"<<endl;
    result1=a.squrt();
    cout<<a<<"sqrt"<<"="<<result1<<endl;
    result1=b.squrt();
    cout<<b<<"sqrt"<<"="<<result1<<endl;
    result1=bb.squrt();
    cout<<bb<<"sqrt"<<"="<<result1<<endl;
    cout<<endl;

}



