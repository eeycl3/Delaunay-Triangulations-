#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include "stdlib.h"
#include <math.h>
#include "Task5.h"
#include <omp.h>
using namespace std;
int main()
{
ifstream fin("triangulation#1.tri");
plat<int,double> triangulation(fin);
functor_f<double> f;//f=5x+2y+2
//for (int i=0;i<10000;i++)
triangulation.find_triangles_contain_xy(-147.16,-4.33801);

for (int i=0;i<10000;i++)
{
cout<<"linear: "<<triangulation.linear_interpolation_approximation(f)<<endl;

//for (int i=0;i<10000;i++)
cout<<"constant: "<<triangulation.constant_value_approximation(f)<<endl;
}
}

