#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include "stdlib.h"
#include <vector>
using namespace std;
template<typename R,typename T>
struct vertice //vertice 3-D, contains x,y,z
{
public:
    R n;    //vertice id
    T x,y,z;    //coordinates (x,y,z)
};

template<typename R>
struct triangle //triangle contains 3 vertices ID
{
    public:
            R n;      //no_cells
            R v[3];    //vertice ID

};

template<typename T>
struct functor_f //function f
{
    T  operator()(T x, T y)
    {
        // users could write function f in here
        return T(x*5+y*2+2);
    }

};
template <typename U, typename P>
class plat //triangulation interface
{
private:
    vector <vertice<U,P> > vertice1;   // vector vertice1
    vector <triangle<U> > triangle1; //vector  triangle1

public:
    plat(vector <vertice<U,P> > ver,vector <triangle<U> > tri)//constructor
    {
        vertice1=ver;
        triangle1=tri;

    }
    plat (const plat<U,P>& tv)// copy constructor
    {
        vertice1=tv.vertice1;
        triangle1=tv.triangle1;
    }

    ~plat() {}; //destructor

    plat& operator=(const plat<U,P>& p)//operator =
    {
        if(this==&p) return(*this);
        vertice1=p.vertice1;
        triangle1=p.triangle1;
        return (*this);
    }

    plat(istream &fin)//I/O file constructor
{
 U no_points, dimensions,no_vertice_arrtibutes,*v_arrtributes;
    vertice<U,P> temp;

    fin>>no_points>>dimensions>>no_vertice_arrtibutes;
    v_arrtributes=new U [no_vertice_arrtibutes];

    for (U i=0;i<no_points;i++)
    {
    fin>>temp.n>>temp.x>>temp.y>>temp.z;
    for (U j=0;j<no_vertice_arrtibutes;j++)
    fin>>v_arrtributes[j];
    vertice1.push_back(temp); //add vertice to vector vertice1

    }

    U no_cells, no_vertice_per_cell,no_tri_arrtibutes; double *t_arrtributes;
    triangle<U> tri;

    fin>>no_cells>>no_vertice_per_cell>>no_tri_arrtibutes;

    t_arrtributes=new double [no_tri_arrtibutes];
    for (U i=0;i<no_cells;i++)
    {

        fin>>tri.n>>tri.v[0]>>tri.v[1]>>tri.v[2];

        for (U j=0;j<no_tri_arrtibutes;j++)
        {
        fin>>t_arrtributes[j];
        }
        triangle1.push_back(tri); //add triangles to vector
    }





}

vector<U> find_triangles_contain_xy(P x,P y)// function to find the triangle contain (x,y)
    {

                vector<U> i_array;
       for(U i=0;i<triangle1.size();i++)
        {
            /*  p = v0 + (v1 - v0) * s + (v2 - v0) * t, where v0,v1,v2 is the vertexes of the triangle
                if (1>s>=0) && (1>t>=0) && (s+t<=1) then p is in the triangle
                s,t and 1 - s - t are called the barycentric coordinates of the point p.
            */
       P s = ((vertice1[triangle1[i].v[1]].y - vertice1[triangle1[i].v[2]].y)*(x - vertice1[triangle1[i].v[2]].x) + (vertice1[triangle1[i].v[2]].x - vertice1[triangle1[i].v[1]].x)*(y - vertice1[triangle1[i].v[2]].y)) /((vertice1[triangle1[i].v[1]].y - vertice1[triangle1[i].v[2]].y)*(vertice1[triangle1[i].v[0]].x - vertice1[triangle1[i].v[2]].x) + (vertice1[triangle1[i].v[2]].x - vertice1[triangle1[i].v[1]].x)*(vertice1[triangle1[i].v[0]].y - vertice1[triangle1[i].v[2]].y));
       P t = ((vertice1[triangle1[i].v[2]].y - vertice1[triangle1[i].v[0]].y)*(x - vertice1[triangle1[i].v[2]].x) + (vertice1[triangle1[i].v[0]].x - vertice1[triangle1[i].v[2]].x)*(y - vertice1[triangle1[i].v[2]].y)) /((vertice1[triangle1[i].v[1]].y - vertice1[triangle1[i].v[2]].y)*(vertice1[triangle1[i].v[0]].x - vertice1[triangle1[i].v[2]].x) + (vertice1[triangle1[i].v[2]].x - vertice1[triangle1[i].v[1]].x)*(vertice1[triangle1[i].v[0]].y - vertice1[triangle1[i].v[2]].y));
        if ((s>=0) && (t>=0) && (s+t<=1))
        {
            i_array.push_back(i);
            cout<<triangle1[i].n<<" triangle contain this point"<<endl;
        }

        }

   if (i_array.size()==0) cout<<"no triangles contain this point"<<endl;
    return i_array;
    }


P triangle_area(U i)    //calculate triangle array
{
    /*
     Area=1/2|(x_A - x_C) (y_B - y_A) - (x_A - x_B) (y_C - y_A)|
    */
  return fabs(0.5*(vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[1]].y + vertice1[triangle1[i].v[1]].x*vertice1[triangle1[i].v[2]].y + vertice1[triangle1[i].v[2]].x*vertice1[triangle1[i].v[0]].y-
                vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[2]].y - vertice1[triangle1[i].v[1]].x*vertice1[triangle1[i].v[0]].y - vertice1[triangle1[i].v[2]].x*vertice1[triangle1[i].v[1]].y));
}

P circumcenter_y(U i)   //calculate triangle circumcenter y coordinate
{
    /*
     center_y=[(Ax^2+Ay^2)(Cx-Bx)+(Bx^2+By^2)(Ax-Cx)+(Cx^2+Cy^2)(Bx-AX)]/D
      where D=2[Ax(By-Cy)+Bx(Cy-Ay)+Cx(Ay-By)]
    */
 return ((vertice1[triangle1[i].v[2]].x-vertice1[triangle1[i].v[0]].x)*(vertice1[triangle1[i].v[1]].x*vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[0]].x+
vertice1[triangle1[i].v[1]].y*vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y*vertice1[triangle1[i].v[0]].y)+(vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x)*
(vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[0]].x-vertice1[triangle1[i].v[2]].x*vertice1[triangle1[i].v[2]].x+vertice1[triangle1[i].v[0]].y*vertice1[triangle1[i].v[0]].y-vertice1[triangle1[i].v[2]].y*vertice1[triangle1[i].v[2]].y))
/(2*(vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y)*(vertice1[triangle1[i].v[2]].x-vertice1[triangle1[i].v[0]].x)-2 *(vertice1[triangle1[i].v[2]].y-vertice1[triangle1[i].v[0]].y)*(vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x));
}

P circumcenter_x(U i) //calculate triangle circumcenter x coordinate
{
    /*
     center_X=[(Ax^2+Ay^2)(By-Cy)+(Bx^2+By^2)(Cy-Ay)+(Cx^2+Cy^2)(Ay-By)]/D
      where D=2[Ax(By-Cy)+Bx(Cy-Ay)+Cx(Ay-By)]
    */
 return ((vertice1[triangle1[i].v[2]].y-vertice1[triangle1[i].v[0]].y)*(vertice1[triangle1[i].v[1]].y*vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y*vertice1[triangle1[i].v[0]].y+
vertice1[triangle1[i].v[1]].x*vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[0]].x)+(vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y)*

(vertice1[triangle1[i].v[0]].y*vertice1[triangle1[i].v[0]].y-vertice1[triangle1[i].v[2]].y*vertice1[triangle1[i].v[2]].y+vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[0]].x-vertice1[triangle1[i].v[2]].x*vertice1[triangle1[i].v[2]].x))
/(2*(vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x)*(vertice1[triangle1[i].v[2]].y-vertice1[triangle1[i].v[0]].y)-2*(vertice1[triangle1[i].v[2]].x-vertice1[triangle1[i].v[0]].x)*(vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y));
}
template<typename T>
P linear_interpolation_approximation(functor_f<T> f)    //calculate integration of f(x,y)
    {
        P sum=0;
        //cout<<"Linear value:"<<endl;
        for (U i=0;i<triangle1.size();i++)
        // 1/3 A(F1+F2+F3)
        sum=sum+(1.0/3)*triangle_area(i)*(f(vertice1[triangle1[i].v[2]].x,vertice1[triangle1[i].v[2]].y)+f(vertice1[triangle1[i].v[1]].x,vertice1[triangle1[i].v[1]].y)+f(vertice1[triangle1[i].v[0]].x,vertice1[triangle1[i].v[0]].y));
        return sum;
    }
template<typename T>
P constant_value_approximation(functor_f<T> f)  //calculate integration of f(x,y)
    {
          P sum=0;
            //cout<<"Constant value:"<<endl;
            for (U ii=0;ii<triangle1.size();ii++)
                //Area*f(Ox,Oy)
            sum=sum+f(circumcenter_x(ii),circumcenter_y(ii))*triangle_area(ii);
            return sum;
    }

};
