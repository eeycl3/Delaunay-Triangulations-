#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include "stdlib.h"
#include <math.h>
#include "task4.h"
using namespace std;

int main()
{
ifstream fin("triangulation#2.tri");
plat<int,double> triangulation(fin);
functor_f<double> f;//f=5x+2y+2
triangulation.find_triangles_contain_xy(-147.16,-4.33801);
cout<<"linear: "<<triangulation.linear_interpolation_approximation(f)<<endl;
cout<<"constant: "<<triangulation.constant_value_approximation(f)<<endl;
}
