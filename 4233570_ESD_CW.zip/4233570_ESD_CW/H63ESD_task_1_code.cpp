#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

int main(int argc, char* argv[]) {

        int nx(10000);//make it to const

        int ny(200);//make it to const

        int nt(200);//make it to const

        double** vi=new double*[nx];    //The array's memory address is not continuous. Another method should be used.

        double** vr=new double*[nx];  //The array's memory address is not continuous.

        double pi=(4.*atan(1.));//make it to const.

        for(int i=0;i<nx;i++) {

                vi[i]=new double[ny];

                vr[i]=new double[ny];

        }

        for(int i=0;i<nx;i++) {

                for(int j=0;j<ny;j++) {

                //pi/double(nx) is constant. It is no need to calculate every times call a const double to store pi/nx value
                        vi[i][j]=double(i*i)*double(j)*sin(pi/double(nx)*double(i));

                        vr[i][j]=0.; //no need to set vr array values here. if necessary, using memset/memcpy where possible to avoid loops
                }
        }


        ofstream fout("data_out");

        for(int t=0;t<nt;t++) {//++t is faster than t++ general

                cout<<"\n"<<t;cout.flush();

                // The following for loop can be divided into different part to reduce the repeated calculation caused by the bounds checking.
                for(int i=0;i<nx;i++) { //++i is faster than i++ general

                        for(int j=0;j<ny;j++) {//++j is faster than j++ general

                                if(i>0&&i<nx-1&&j>0&&j<ny-1) { // There are too many if statements here and too many branches. The bounds checking is not good.

                                        vr[i][j]=(vi[i+1][j]+vi[i-1][j]+vi[i][j-1]+vi[i][j+1])/4.;// division is slower than multiplication and change it to *0.25

                                } else if(i==0&&i<nx-1&&j>0&&j<ny-1) {  // The bounds checking is not good.

                                        vr[i][j]=(vi[i+1][j]+10.+vi[i][j-1]+vi[i][j+1])/4.; // division is slower than multiplication and change it to *0.25

                                } else if(i>0&&i==nx-1&&j>0&&j<ny-1) { //The bounds checking is not good.

                                        vr[i][j]=(5.+vi[i-1][j]+vi[i][j-1]+vi[i][j+1])/4.;// division is slower than multiplication and change it to *0.25

                                } else if(i>0&&i<nx-1&&j==0&&j<ny-1) { //The bounds checking is not good.

                                        vr[i][j]=(vi[i+1][j]+vi[i-1][j]+15.45+vi[i][j+1])/4.;// division is slower than multiplication and change it to *0.25

                                } else if(i>0&&i<nx-1&&j>0&&j==ny-1) { //The bounds checking is not good.

                                        vr[i][j]=(vi[i+1][j]+vi[i-1][j]+vi[i][j-1]-6.7)/4.;// division is slower than multiplication and change it to *0.25

                                }
                        }
                }

                for(int i=0;i<nx;i++) {

                        for(int j=0;j<ny;j++) {

                                //it can be using  two variables to save the fabs(vr[i][j]) and fabs(vi[i][j]) value. No need to call fabs() twice.
                                if(fabs(fabs(vr[i][j])-fabs(vi[i][j]))<1e-2) fout<<"\n"<<t<<" "<<i<<" "<<j<<" "<<fabs(vi[i][j])<<" "<<fabs(vr[i][j]);

                        }
                }
                // LOOP here is not necessary.
                for(int i=0;i<nx;i++) {

                        for(int j=0;j<ny;j++) vi[i][j]=vi[i][j]/2.+vr[i][j]/2.; //the calculation can be added to the loop which is used to output the file. To save the loop management

                }
        }
}

