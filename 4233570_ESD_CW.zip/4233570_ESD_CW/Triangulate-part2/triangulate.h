#include <iostream>
#include <vector>
#include <math.h>
#include <vector>
#include <fstream>
#include <algorithm>
#include <memory>
using namespace std;

template<typename R,typename T>
struct vertice //vertice 3-D, contains x,y,z
{
public:
    R n;
    T x,y,z;
};
template <typename R>
struct line
{
public:
        R v1;
        R v2;
};

template<typename R>
struct triangle //triangle contains 3 vertices
{
public:
    R n;      //no_cells
    R v[3];
};
template<typename U,typename P>
class Triangulate
{
private:
        vector<vertice<U,P> > vertice1;
        vector<triangle<U> > triangle1;

public :
        Triangulate(istream &fin)
        {
             U no_points, dimensions,no_vertice_arrtibutes;
            vertice<U,P> temp;
            fin>>no_points>>dimensions>>no_vertice_arrtibutes;
            for (U i=0;i<no_points;i++)
            {
                fin>>temp.n>>temp.x>>temp.y;
                vertice1.push_back(temp); //add to vector

            }
        }
P circumcenter_y(U i)
{
 return ((vertice1[triangle1[i].v[2]].x-vertice1[triangle1[i].v[0]].x)*(vertice1[triangle1[i].v[1]].x*vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[0]].x+
vertice1[triangle1[i].v[1]].y*vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y*vertice1[triangle1[i].v[0]].y)+(vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x)*
(vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[0]].x-vertice1[triangle1[i].v[2]].x*vertice1[triangle1[i].v[2]].x+vertice1[triangle1[i].v[0]].y*vertice1[triangle1[i].v[0]].y-vertice1[triangle1[i].v[2]].y*vertice1[triangle1[i].v[2]].y))
/(2*(vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y)*(vertice1[triangle1[i].v[2]].x-vertice1[triangle1[i].v[0]].x)-2 *(vertice1[triangle1[i].v[2]].y-vertice1[triangle1[i].v[0]].y)*(vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x));
}

P circumcenter_x(U i)
{
 return ((vertice1[triangle1[i].v[2]].y-vertice1[triangle1[i].v[0]].y)*(vertice1[triangle1[i].v[1]].y*vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y*vertice1[triangle1[i].v[0]].y+
vertice1[triangle1[i].v[1]].x*vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[0]].x)+(vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y)*
(vertice1[triangle1[i].v[0]].y*vertice1[triangle1[i].v[0]].y-vertice1[triangle1[i].v[2]].y*vertice1[triangle1[i].v[2]].y+vertice1[triangle1[i].v[0]].x*vertice1[triangle1[i].v[0]].x-vertice1[triangle1[i].v[2]].x*vertice1[triangle1[i].v[2]].x))
/(2*(vertice1[triangle1[i].v[1]].x-vertice1[triangle1[i].v[0]].x)*(vertice1[triangle1[i].v[2]].y-vertice1[triangle1[i].v[0]].y)-2*(vertice1[triangle1[i].v[2]].x-vertice1[triangle1[i].v[0]].x)*(vertice1[triangle1[i].v[1]].y-vertice1[triangle1[i].v[0]].y));
}


   bool inside_circumcircle(U i,P xp,P yp)
{
    //const double EPSILON = 0.000001;
       P xc=circumcenter_x(i);
       P yc=circumcenter_y(i);
  P dx = vertice1[triangle1[i].v[0]].x - xc;
  P dy = vertice1[triangle1[i].v[0]].y- yc;
  P R_sqr = dx * dx + dy * dy;
   dx = xp - xc;
   dy = yp - yc;
  P D_sqr = dx * dx + dy * dy;
  return((D_sqr <= R_sqr) ? true : false);
}

   void  ge_triangulation()
   {
// find boundaries xmax,ymax,xmin,ymin;
 P xmin = vertice1[0].x;
 P ymin = vertice1[0].y;
 P xmax = xmin;
 P ymax = ymin;
  for(int i = 1; i < vertice1.size(); i++)
    {
    xmin = min(vertice1[i].x,xmin);
    xmax = max(vertice1[i].x,xmax);
    ymin = min(vertice1[i].y,ymin);
    ymax = max(vertice1[i].y,ymax);
    }
  P dx = xmax - xmin;
  P dy = ymax - ymin;
  P dmax = (dx > dy) ? dx : dy;
  P xmid = (xmax + xmin) *0.5;
  P ymid = (ymax + ymin) *0.5;

//set up the super triangle and add it to the vector list.
  vertice<U,P> temp[3];
  temp[0].x = xmid - 20 * dmax;
  temp[0].y = ymid - dmax;
  temp[0].n=vertice1.size();
  //cout<<temp[0].n;
  vertice1.push_back(temp[0]);
  temp[1].x = xmid;
  temp[1].y = ymid + 20 * dmax;
  temp[1].n=vertice1.size();
   // cout<<temp[1].n;
  vertice1.push_back(temp[1]);
  temp[2].x = xmid + 20 * dmax;
  temp[2].y = ymid - dmax;
  temp[2].n=vertice1.size();
    //cout<<temp[2].n;
  vertice1.push_back(temp[2]);
  triangle<U> tri;
  tri.n=0;
  tri.v[0]=temp[0].n;
  tri.v[1]=temp[1].n;
  tri.v[2]=temp[2].n;
  triangle1.push_back(tri);
	for(U i=0; i< vertice1.size()-3; i++)
	{


		vector<triangle<U> > badTriangles;
		vector<line<U> > polygon;

		for(U j = 0; j <triangle1.size(); j++)
		{


            // if xc+R+ EPSILON <xp; roughing
			if(inside_circumcircle(j,vertice1[i].x,vertice1[i].y))
			{

              badTriangles.push_back(triangle1[j]);
				                 line<U> e1;
                    e1.v1=triangle1[j].v[0];
				    e1.v2=triangle1[j].v[1];
				    line<U> e2;
                    e2.v1=triangle1[j].v[1];
				    e2.v2=triangle1[j].v[2];
				    line<U> e3;
                    e3.v1=triangle1[j].v[0];
				    e3.v2=triangle1[j].v[2];
                polygon.push_back(e1);
				polygon.push_back(e2);
				polygon.push_back(e3);


			}
			else
			{
				//std::cout << " does not contains " << *p << " in his circum center" << std::endl;
			}
		}
//erase bad triangles
    //vector<triangle<int> >::iterator i_bad; vector<triangle<int> >::iterator i_tri;
    for ( U i_bad=0;i_bad<badTriangles.size();i_bad++)
    {
        for(U i_tri=0;i_tri<triangle1.size();i_tri++)
            if ((badTriangles[i_bad].v[0]==triangle1[i_tri].v[0])&&(badTriangles[i_bad].v[1]==triangle1[i_tri].v[1])&&(badTriangles[i_bad].v[2]==triangle1[i_tri].v[2]))

                {triangle1.erase(i_tri+triangle1.begin()); i_tri--;}
    }

//find badEdges

		vector<line<int> > badEdges;
		for(U i_p1  = 0; i_p1< polygon.size(); i_p1++)
		{
			for(U i_p2  = 0; i_p2<polygon.size(); i_p2++)
			{
				if(i_p1 == i_p2)
					continue;

				if(((polygon[i_p1].v1 == polygon[i_p2].v1)&&(polygon[i_p1].v2 == polygon[i_p2].v2))||((polygon[i_p1].v2 == polygon[i_p2].v1)&&(polygon[i_p1].v1 == polygon[i_p2].v2)))
				{
					badEdges.push_back(polygon[i_p1]);
					badEdges.push_back(polygon[i_p2]);
				}
			}
		}
//erase bad edges;
		   for(U i_p1  = 0; i_p1<polygon.size(); i_p1++)
			for(U i_p2  = 0; i_p2<badEdges.size();i_p2++)
			{
				if(((polygon[i_p1].v1 == badEdges[i_p2].v1)&&(polygon[i_p1].v2 == badEdges[i_p2].v2))||((polygon[i_p1].v2 == badEdges[i_p2].v1)&&(polygon[i_p1].v1 == badEdges[i_p2].v2)))
					{
					    polygon.erase(polygon.begin()+i_p1);
                        i_p1--;
                    }
			}


		for(U e = 0; e <polygon.size(); e++)
			{

			     tri.v[0]=i;
			     tri.v[1]=polygon[e].v1;
			     tri.v[2]=polygon[e].v2;
			     tri.n=triangle1.size();
			    triangle1.push_back(tri);
			}

	}
	//erase triangles has super triangles'vertex

		  for(U i_tri=0;i_tri<triangle1.size();i_tri++)
            if ((triangle1[i_tri].v[0]>=(vertice1.size()-3))||(triangle1[i_tri].v[1]>=(vertice1.size()-3))||(triangle1[i_tri].v[2]>=(vertice1.size()-3)))
               {triangle1.erase(i_tri+triangle1.begin()); i_tri--;
               }




	}
void output()
{
    const int d(3);
    const int f(0);
    ofstream fout("output.tri");

        fout<<vertice1.size()-3<<" "<<d<<" "<<f<<endl;
        for (U i=0;i<vertice1.size()-3;i++)
        {
           fout<<vertice1[i].n<<" "<<vertice1[i].x<<" "<<vertice1[i].y<<" "<<f<<endl;
        }
         fout<<triangle1.size()<<" "<<d<<" "<<f<<endl;
        for (U j=0;j<triangle1.size();j++)
        {
            fout<<j<<" "<<triangle1[j].v[0]<<" "<<triangle1[j].v[1]<<" "<<triangle1[j].v[2]<<endl;
        }
fout<<"property_no"<<endl;
fout<<"is_missing:0 means yes"<<endl;
fout<<"is_encroached:0 means yes"<<endl;
fout<<"Panel no"<<endl;
fout<<"cell id"<<endl;
fout<<"in_tet.size"<<endl;
fout<<"Quality^2"<<endl;
fout<<"In Quality measure lists"<<endl;
fout<<"Quality_bounded_by_segment_angle"<<endl;
fout<<"circumradius^2.mid"<<endl;
fout<<"Sqrt(area)"<<endl;
fout<<"Random"<<endl;
fout<<"No NULL neighbours"<<endl;
fout<<"Facet is_coordinate_aligned"<<endl;
fout<<"Is coplanar"<<endl;
fout<<"does_shortest_edge_connect_segments"<<endl;
fout<<"No contained segments"<<endl;

    fout.close();

}

};
