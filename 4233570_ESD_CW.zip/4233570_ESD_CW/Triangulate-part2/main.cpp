#include <iostream>
#include <vector>
#include <math.h>
#include <vector>
#include <fstream>
#include <memory>
#include "triangulate.h"




using namespace std;




int main()
{



    ifstream fin("vertices#3.node");
    Triangulate<int,double> file1(fin);
    file1.ge_triangulation();

    file1.output();


    return 0;
}
