#include <iostream>
#include <sys/time.h>
using namespace std;

int main()
{
    struct timeval start_time,end_time;
    long  n;
    long  offset;
    const int m(200);
    long i(0);

     cin>>n;
     cin>>offset;
     double *a=new double[n];
     double *b=new double[n];
     double *c=new double[n];
    for(i=1;i<n;i++)    //init b
    {
        b[i]=c[i]=i;
    }
    gettimeofday(&start_time,NULL);
    for (int j=0;j<m;j++)   //m=200 200 sum loop
    {
        for (i=1;i<n-offset;i++)
        {
         a[i]=b[i]+c[i+offset];
        }
    }
    gettimeofday(&end_time,NULL);
    cout<<"\n\ngettimeofday wall time="<<end_time.tv_sec - start_time.tv_sec+(end_time.tv_usec-start_time.tv_usec)/1e6<<endl;
}


