#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

int main(int argc, char* argv[])
{

const int nx(10000);
const int ny(200);
const int nt(200);
const double pi_div_nx((4.*atan(1.))/double(nx));// Make it a constant
double(* vi)[ny]=new double[nx][ny]; //make vi array memory address continuous
double(* vr)[ny]=new double[nx][ny];//make vr array memory address continuous

for(int i=0;i<nx;++i)
{
    for(int j=0;j<ny;++j)
    vi[i][j]=(sin(pi_div_nx*double(i))*double(i*i))*double(j); //initialize the vi array
}

vr[0][0]=0.;
ofstream fout("data_out");

for( int t=0;t<nt;++t)
    {
        cout<<"\n"<<t;
        cout.flush();

        for (int j=1;j<ny-1;++j)
        {   //reduce calculations such as nx-1 and use multiplication
            vr[0][j]=(vi[1][j]+10.+vi[0][j-1]+vi[0][j+1])*0.25;
            vr[9999][j]=(5.+vi[9998][j]+vi[9999][j-1]+vi[9999][j+1])*0.25;
        }

        for(int i=1;i<nx-1;++i)
        {   //reduce calculations such as ny-1 and, use multiplication
            vr[i][0]=(vi[i+1][0]+vi[i-1][0]+15.45+vi[i][1])*0.25;
            vr[i][199]=(vi[i+1][199]+vi[i-1][199]+vi[i][198]-6.7)*0.25;
        }

        for( int i=1;i<nx-1;++i)
            for(int j=1;j<ny-1;++j)
                vr[i][j]=(vi[i+1][j]+vi[i-1][j]+vi[i][j-1]+vi[i][j+1])*0.25;

        for(int i=0;i<nx;++i)
        for(int j=0;j<ny;++j)
        {
         //Two variables are tried to store the fabs(vr[i][j]) and fabs(vi[i][j]) to reduce the times of calling fabs(),
         // but it make the program slower
        if(fabs(fabs(vr[i][j])-fabs(vi[i][j]))<1e-2) fout<<"\n"<<t<<" "<<i<<" "<<j<<" "<<fabs(vi[i][j])<<" "<<fabs(vr[i][j]);
        vi[i][j]=vi[i][j]*0.5+vr[i][j]*0.5;
        }

    }
}
























































































